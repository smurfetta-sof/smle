from flask_wtf import FlaskForm
from wtforms import TextAreaField, StringField, PasswordField, BooleanField, SubmitField
from wtforms.validators import DataRequired, Length, Email, Regexp, EqualTo
from wtforms import ValidationError


class LoginForm(FlaskForm):
    username = StringField('Login', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    remember_me = BooleanField('Keep me logged in')
    submit = SubmitField('Log In')


class AddPostsForm(FlaskForm):
    title = StringField('Title', validators=[DataRequired()])
    post = TextAreaField('Article', validators=[DataRequired()])
    
    submit = SubmitField('Add post')


class AddNewsForm(FlaskForm):
    title = StringField('Заголовок новости', validators=[DataRequired()])
    content = TextAreaField('Текст новости', validators=[DataRequired()])
    submit = SubmitField('Add news')

class AddWordForm(FlaskForm):
    word = StringField('Математический термин', validators=[DataRequired()])
    translation = TextAreaField('Translation', validators=[DataRequired()])
    sub = StringField('Category', validators=[DataRequired()])
    submit = SubmitField('Add word')

    
class AddArticleForm(FlaskForm):
    title = StringField('Title', validators=[DataRequired()])
    content = TextAreaField('Article', validators=[DataRequired()])
    issue_1 = StringField('Вопрос 1', validators=[DataRequired()])
    issue_2 = StringField('Вопрос 2', validators=[DataRequired()])
    issue_3 = StringField('Вопрос 3', validators=[DataRequired()])
    answer = StringField('Ответ правильный', validators=[DataRequired()])
    submit = SubmitField('Add article')
