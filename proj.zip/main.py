from flask import Flask, session, request, redirect, request
from flask import render_template
from forms import LoginForm, AddArticleForm, AddNewsForm, AddPostsForm, AddWordForm
from bd2 import DB, AlbumsModel, ArticlesModel, NewsModel, UsersModel, PostsModel
import random

db = DB()


app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'

@app.route('/')
@app.route('/index')
def index():
    if 'username' not in session:
        return redirect('/login')
    news = NewsModel(db.get_connection()).get_all(session['user_id'])
    return render_template('index.html', username=session['username'], news=news)


@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        user_name = form.username.data
        password = form.password.data
        user_model = UsersModel(db.get_connection())
        exists = user_model.exists(user_name, password)
        if (exists[0]):
            session['username'] = user_name
            session['user_id'] = exists[1]
        return redirect("/index")
    return render_template('login.html', title='Авторизация', form=form)


@app.route('/logout')
def logout():
    session.pop('username',0)
    session.pop('user_id',0)
    return redirect('/login')


@app.route('/about')
def about():
    content = 'Описание проекта будет тут...'
    return render_template('about.html', title='About',content=content)


# Albums
@app.route('/albums')
def albums():
    alobj = AlbumsModel(db.get_connection())
    word = alobj.get_all()
    return render_template('albums.html', title='Albums', word=word)

@app.route('/albums/<category>')
def albums_category(category):
    alobj = AlbumsModel(db.get_connection())
    word = alobj.get_all(category)
    return render_template('albums.html', title='Albums', category=category, word=word)

@app.route('/albums/test/<id_word>/<user_word>')
def albums_test_answer(id_word, user_word):
    wobj = AlbumsModel(db.get_connection())
    word1 = wobj.get(id_word)
    word2 = ''
    if id_word == user_word:
        err_answer = 0
        return render_template('albums_test.html', title='Test', err_answer=err_answer,
                               word2=word2, word1=word1)
    elif id_word != user_word:
        err_answer = 1
        return render_template('albums_test.html', title='Test', err_answer=err_answer,
                               word2=word2, word1=word1)
        
    return render_template('albums_test.html', title='Test', word2=word2,
                           word1=word1, word_set=word_set)

    
@app.route('/albums/test')
def albums_test():
    alobj = AlbumsModel(db.get_connection())
    word = alobj.get_all()
    col = len(word)
    word1_id = random.randrange(1,col)
    word1 = alobj.get(word1_id)
    i=1
    word_set = set()
    word_set_id = set()
    #word_set.add(str(word1[2]))
    word2 = []
    word_temp = []
    word2.append(word1)
    while i < 5:
        col_i = random.randrange(1,col)
        word_t = alobj.get(col_i)
        word2.append(word_t)
        i += 1
    for ii in word2:
        word_set.add(ii[0])
        
    word2.sort()
    
    
             
    return render_template('albums_test.html', title='Test', word2=word2,
                           word1=word1, word_temp=word_temp)


@app.route('/add_word', methods=['GET', 'POST'])
def add_word():
    form = AddWordForm()
    if form.validate_on_submit():
        word = form.word.data
        translation = form.translation.data
        sub = form.sub.data
        ws = AlbumsModel(db.get_connection())
        ws.insert(word, translation, sub)
        return redirect('/albums')
    return render_template('add_word.html', title='Add Article', form=form)
    


# Новости проекта
@app.route('/news')
def news():
    newsobj = NewsModel(db.get_connection())
    news = newsobj.get_all()
    return render_template('news.html', title='News', news=news)

    
    #return render_template('news.html', title='News', content=news_list)

@app.route('/add_news', methods=['GET', 'POST'])
def add_news():
    if 'username' not in session:
        return redirect('/login')
    form = AddNewsForm()
    if form.validate_on_submit():
        title = form.title.data
        content = form.content.data
        nm = NewsModel(db.get_connection())
        nm.insert(title,content,session['user_id'])
        return redirect("/news")
    return render_template('add_news.html', title='Add News',
                           form=form)
 

@app.route('/blog') 
def blog():
    user = {'username': 'Sonik'}
    posts = [
        {
            'author': {'username': 'Peter'},
            'body': 'Beautiful day in Portland! fdg etg t gtg thrt hg ghrthr rt ryhryh yhyrrhr '
        },
        {
            'author': {'username': 'Susan'},
            'body': 'The Avengers movie was so cool!'
        }
    ]
    return render_template('blog.html', title='Blog', posts=posts)


@app.route('/articles')
def articles():
    arobj = ArticlesModel(db.get_connection())
    articles = arobj.get_all()
    return render_template('articles.html', title='Articles', articles=articles)


@app.route('/article/<id_article>', methods=['GET', 'POST'])
def article(id_article):
    arobj = ArticlesModel(db.get_connection())
    article = arobj.get(id_article)
    return render_template('article.html', title='Article', article=article)

# Обработчик правильности ответов article
@app.route('/article/<id_article>/<int:id_answer>')
def article_answer(id_article, id_answer):
    arobj = ArticlesModel(db.get_connection())
    article = arobj.get(id_article)
    if article[6] == id_answer:
        err_answer = 0
        return render_template('article.html', title='Article', err_answer=err_answer, article=article)
    elif article[6] != id_answer:
        err_answer = 1
        return render_template('article.html', title='Article', err_answer=err_answer, article=article)
        
    return render_template('article.html', title='Article', article=article)


@app.route('/add_article', methods=['GET', 'POST'])
def add_article():
    form = AddArticleForm()
    if form.validate_on_submit():
        title = form.title.data
        content = form.content.data
        issue_1 = form.issue_1.data
        issue_2 = form.issue_2.data
        issue_3 = form.issue_3.data
        answer = form.answer.data
        ar = ArticlesModel(db.get_connection())
        ar.insert(title, content, issue_1, issue_2, issue_3, answer)
        return redirect('/articles')
    return render_template('add_article.html', title='Add Article', form=form)



if __name__ == '__main__':
    app.debug=True # для тестирования
    app.run(port=8080, host='127.0.0.1')
