from bd2 import DB, AlbumsModel, ArticlesModel, NewsModel, UsersModel, PostsModel 

db = DB()

news = NewsModel(db.get_connection())
news.init_table()
#news.insert('Первай новость проекта!', 'Все началось с идеи проекта!!!', 1)
#news.insert('Вторая новость проекта!', 'План проекта следующий: сделать функционал, закачать данные и затем вывести на продуктивное использование!!!', 1)
#news.insert('Третья новость проекта!', 'Тут мы можем и скорректировать наш План проекта следующий: сделать функционал, закачать данные и затем вывести на продуктивное использование!!!', 1)
nw = news.get_all()


ar = ArticlesModel(db.get_connection())
a = ar.init_table()
ar.insert('Тема статьи', 'Статья о математиках или о математике или термины математические', 'Вопрос1', 'Вопрос2', 'Вопрос3', '2')
ar.insert('Тема статьи 2', 'Статья вторая о математиках или о математике или термины математические', 'Вопрос1', 'Вопрос2', 'Вопрос3', '3')
arp = ar.get_all()
print(arp)




al = AlbumsModel(db.get_connection())
al.init_table()
a = al.get_all('alg')
#print(a)

#al.insert('абсциса', 'abscissa', 'alg')
#al.insert('аксиома', 'axiom', 'base')
#al.insert('аргумент', 'argument', 'alg')
#al.insert('среднее арифметическое', 'arithmetical average', 'alg')
#al.insert('арифметическая прогрессия', 'arithmetical progression', 'alg')
#al.insert('арифметическое значение корня', 'principal root', 'alg')
#al.insert('асимметрия', 'asymmetry', 'geo')
#al.insert('асимптота', 'asymptote', 'alg')
#al.insert('базис', 'basis', 'geo')
#al.insert('безграничный', 'boundless', 'base')
#al.insert('безразмерный', 'dimensionless', 'base')
#al.insert('бесконечность', 'infinity', 'base')
#al.insert('биквадратное уравнение', 'biquadratic equation', 'alg')
#al.insert('бином', 'binomialа', 'alg')
#al.insert('биссектриса', 'bisector', 'geo')
#al.insert('боковая сторона', 'flank', 'geo')
#al.insert('больше', 'more', 'alg')
#al.insert('вектор', 'vector', 'geo')


list_a = [('абсциса', 'abscissa', 'alg'),
          ('аксиома', 'axiom', 'base'),
          ('аргумент', 'argument', 'alg'),
          ('среднее арифметическое', 'arithmetical average', 'alg'),
          ('арифметическая прогрессия', 'arithmetical progression', 'alg'),
          ('арифметическое значение корня', 'principal root', 'alg'),
          ('асимметрия', 'asymmetry', 'geo'),
          ('асимптота', 'asymptote', 'alg'),
          ('базис', 'basis', 'geo'),
          ('безграничный', 'boundless', 'base'),
          ('безразмерный' 'dimensionless', 'base'),
          ('бесконечность' 'infinity', 'base'),
          ('биквадратное уравнение', 'biquadratic equation', 'alg'),
          ('бином', 'binomialа', 'alg'),
          ('биссектриса', 'bisector', 'geo'),
          ('боковая сторона', 'flank', 'geo'),
          ('больше', 'more', 'alg'),
          ('вектор', 'vector', 'geo'),
          ('единичный вектор', 'unit vector', 'geo'),
          ('модуль вектора', 'value of a vector', 'geo'),
          ('векторное произведение', 'cross product', 'geo'),
          ('величина', 'value, magnitude, quantity', 'base'),
          ('вертикальные углы', 'vertical angles', 'geo'),
          ('вершина', 'peak, vertex, apex', 'geo'),
          ('ветвь', 'branch', 'base'),
          ('взаимно однозначное соответствие', 'one-to-one correspondence', 'alg'),
          ('внутренние углы', 'interior angles', 'geo'),
          ('возведение в степень', 'involution', 'base'),
          ('возрастать', 'increase, grow', 'alg'),
          ('восстанавливать перпендикуляр', 'erect a perpendicular', 'geo'),
          ('вписывать', 'inscribe', 'geo'),
          ('вписанная окружность', 'inscribed circle', 'base'),
          ('вращение', 'revolution, rotation', 'base'),
          ('выбор', 'choice', 'base'),
          ('вывод', 'conclusion, consequence', 'base'),
          ('выводить', 'deduce', 'base'),
          ('выпуклость', 'salience, protuberance', 'alg'),
          ('выражение', 'expression, phrase', 'base'),
          ('высота', 'height, altitude', 'alg'),
          ('вычесть', 'subtract', 'base'),
          ('вычисление', 'calculation, computation, estimation', 'base'),
          ('вычисление в уме', 'mental arithmetic', 'base'),
          ('вычитаемое', 'subtrahend, deduction', 'base'),
          ('геометрическое место точек', 'locus', 'geo'),
          ('геометрическая прогрессия', 'geometrical progression', 'alg'),
          ('гипербола', 'hyperbola', 'alg'),
          ('гипотенуза', 'hypotenuse', 'base'),
          ('градус', 'degree', 'geo'),
          ('граница', 'boundary', 'base'),
          ('грань', 'side, face', 'geo'),
          ('график', 'plot, graph', 'alg'),
          ('двенадцатиугольник', 'dodecagon', 'geo'),
          ('движение', 'motione', 'geo'),
          ('двумерный', 'two-dimensional', 'base'),
          ('действительный', 'real', 'base'),
          ('дека`ртовы координаты', 'Cartesian coordinates', 'geo'),
          ('деление', 'division', 'base'),
          ('деление без остатка', 'exact division', 'base'),
          ('деление отрезка', 'section', 'geo'),
          ('делимое', 'divisible', 'base'),
          ('делитель' 'divisor', 'base'),
          ('делится на число', 'contain', 'base'),
          ('диагональ', 'diagonal', 'geo'),
          ('диаметр', 'diameter', 'geo'),
          ('диапазон', 'range', 'base'),
          ('директриса', 'directrix', 'alg'),
          ('длина', 'length', 'geo'),
          ('доказательство', 'proof, evidence, argument', 'base'),
          ('доля', 'quantum', 'base'),
          ('взаимно однозначное соответствие', 'one-to-one correspondence', 'alg'),
          ('внутренние углы', 'interior angles', 'geo'),
          ('возведение в степень', 'involution', 'base'),
          ('возрастать', 'increase, grow', 'alg'),
          ('восстанавливать перпендикуляр', 'erect a perpendicular', 'geo'),
          ('вписывать', 'inscribe', 'geo'),
          ('вписанная окружность', 'inscribed circle', 'base'),
          ('вращение', 'revolution, rotation', 'base'),
          ('выбор', 'choice', 'base'),
          ('вывод', 'conclusion, consequence', 'base'),
          ('выводить', 'deduce', 'base'),
          ('выпуклость', 'salience, protuberance', 'alg'),
          ('выражение', 'expression, phrase', 'base'),
          ('высота', 'height, altitude', 'alg'),
          ('вычесть', 'subtract', 'base'),
          ('вычисление', 'calculation, computation, estimation', 'base'),
          ('вычисление в уме', 'mental arithmetic', 'base'),
          ('вычитаемое', 'subtrahend, deduction', 'base'),
          ('геометрическое место точек', 'locus', 'geo'),
          ('геометрическая прогрессия', 'geometrical progression', 'alg'),
          ('гипербола', 'hyperbola', 'alg'),
          ('гипотенуза', 'hypotenuse', 'base'),
          ('градус', 'degree', 'geo'),
          ('граница', 'boundary', 'base'),
          ('грань', 'side, face', 'geo'),
          ('график', 'plot, graph', 'alg'),
          ('двенадцатиугольник', 'dodecagon', 'geo'),
          ('движение', 'motione', 'geo'),
          ('двумерный', 'two-dimensional', 'base'),
          ('действительный', 'real', 'base'),
          ('дека`ртовы координаты', 'Cartesian coordinates', 'geo'),
          ]
